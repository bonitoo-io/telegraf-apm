package io.bonitoo.demo.demojavaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJavaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
